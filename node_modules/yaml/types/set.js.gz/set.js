const legacy = require('../dist/legacy-exports')
module.exports = legacy.set
legacy.warnFileDeprecation(__filename)
