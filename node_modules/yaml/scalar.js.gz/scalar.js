module.exports = require('./dist/types').Scalar
require('./dist/legacy-exports').warnFileDeprecation(__filename)
