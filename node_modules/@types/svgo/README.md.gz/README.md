# Installation
> `npm install --save @types/svgo`

# Summary
This package contains type definitions for svgo (https://github.com/svg/svgo).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/svgo/v1.

### Additional Details
 * Last updated: Fri, 02 Jul 2021 22:33:14 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [Bradley Ayers](https://github.com/bradleyayers), [Gilad Gray](https://github.com/giladgray), [Aankhen](https://github.com/Aankhen), [Jan Karres](https://github.com/jankarres), [Gavin Gregory](https://github.com/gavingregory), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
