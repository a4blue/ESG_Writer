# Installation
> `npm install --save @types/imagemin-svgo`

# Summary
This package contains type definitions for imagemin-svgo (https://github.com/imagemin/imagemin-svgo#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/imagemin-svgo.

### Additional Details
 * Last updated: Sun, 07 Mar 2021 10:09:12 GMT
 * Dependencies: [@types/svgo](https://npmjs.com/package/@types/svgo), [@types/imagemin](https://npmjs.com/package/@types/imagemin)
 * Global values: none

# Credits
These definitions were written by [Romain Faust](https://github.com/romain-faust), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
