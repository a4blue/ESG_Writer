# Installation
> `npm install --save @types/clean-css`

# Summary
This package contains type definitions for clean-css (https://github.com/jakubpawlowicz/clean-css).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/clean-css.

### Additional Details
 * Last updated: Tue, 06 Jul 2021 18:05:52 GMT
 * Dependencies: [@types/source-map](https://npmjs.com/package/@types/source-map), [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Tanguy Krotoff](https://github.com/tkrotoff), and [Andrew Potter](https://github.com/GolaWaya).
