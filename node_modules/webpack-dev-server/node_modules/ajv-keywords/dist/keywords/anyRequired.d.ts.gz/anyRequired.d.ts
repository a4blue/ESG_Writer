import type { Plugin } from "ajv";
declare const anyRequired: Plugin<undefined>;
export default anyRequired;
