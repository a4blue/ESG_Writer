import type { Plugin } from "ajv";
declare const regexp: Plugin<undefined>;
export default regexp;
