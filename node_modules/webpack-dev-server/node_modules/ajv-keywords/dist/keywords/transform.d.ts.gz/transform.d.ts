import type { Plugin } from "ajv";
declare const transform: Plugin<undefined>;
export default transform;
