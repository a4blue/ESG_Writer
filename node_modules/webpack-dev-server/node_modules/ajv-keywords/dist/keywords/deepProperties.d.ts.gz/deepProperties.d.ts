import type { Plugin } from "ajv";
import type { DefinitionOptions } from "../definitions/_types";
declare const deepProperties: Plugin<DefinitionOptions>;
export default deepProperties;
