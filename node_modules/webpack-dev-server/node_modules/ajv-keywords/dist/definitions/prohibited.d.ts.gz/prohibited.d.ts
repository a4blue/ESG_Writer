import type { MacroKeywordDefinition } from "ajv";
export default function getDef(): MacroKeywordDefinition;
