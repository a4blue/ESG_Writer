import type { Vocabulary } from "../types";
export declare const metadataVocabulary: Vocabulary;
export declare const contentVocabulary: Vocabulary;
