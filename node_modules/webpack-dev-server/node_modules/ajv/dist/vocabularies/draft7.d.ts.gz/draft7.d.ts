import type { Vocabulary } from "../types";
declare const draft7Vocabularies: Vocabulary[];
export default draft7Vocabularies;
