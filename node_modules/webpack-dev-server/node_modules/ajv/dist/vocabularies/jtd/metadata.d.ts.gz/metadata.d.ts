import { KeywordCxt } from "../../ajv";
import type { CodeKeywordDefinition } from "../../types";
declare const def: CodeKeywordDefinition;
export declare function checkMetadata({ it, keyword }: KeywordCxt, metadata?: boolean): void;
export default def;
