import type { SchemaObjCxt } from "..";
export declare function assignDefaults(it: SchemaObjCxt, ty?: string): void;
