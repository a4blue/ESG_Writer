import { LoadersSync } from './types';
declare const loaders: LoadersSync;
export { loaders };
//# sourceMappingURL=loaders.d.ts.map