export function cloneNode(n) {
  return Object.assign({}, n);
}