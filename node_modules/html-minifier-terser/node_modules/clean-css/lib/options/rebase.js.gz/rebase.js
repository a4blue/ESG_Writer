function rebaseFrom(rebaseOption) {
  return undefined === rebaseOption ? true : !!rebaseOption;
}

module.exports = rebaseFrom;
