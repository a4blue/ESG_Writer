declare function isRegex(o: any): boolean;
declare function isFunction(functionToCheck: any): any;
declare function isPlainObject(a: any): boolean;
declare function isUndefined(a: any): boolean;
export { isRegex, isFunction, isPlainObject, isUndefined };
