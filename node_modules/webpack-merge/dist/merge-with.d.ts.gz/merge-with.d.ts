declare function mergeWith(objects: object[], customizer: any): object;
export default mergeWith;
