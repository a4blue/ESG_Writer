import { Customize, Key } from "./types";
export default function joinArrays({ customizeArray, customizeObject, key, }?: {
    customizeArray?: Customize;
    customizeObject?: Customize;
    key?: Key;
}): (a: any, b: any, k: Key) => any;
