export const style: Set<string>;
export const variant: Set<string>;
export const weight: Set<string>;
export const stretch: Set<string>;
export const size: Set<string>;
