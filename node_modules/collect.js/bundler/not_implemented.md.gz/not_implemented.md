##### Methods that have not been implemented:

- ~~`containsStrict`~~ use `contains()`
- ~~`duplicatesStrict`~~ use `duplicates()`
- ~~`uniqueStrict`~~ use `unique()`
- ~~`whereStrict`~~ use `where()`
- ~~`whereInStrict`~~ use `whereIn()`
- ~~`whereNotInStrict`~~ use `whereNotIn()`