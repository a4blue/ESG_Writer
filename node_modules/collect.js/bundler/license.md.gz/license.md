### License

MIT © [Daniel Eckermann](https://danieleckermann.com)