# <img src="https://raw.githubusercontent.com/ecrmnn/collect.js/master/collectjs.jpg" alt="collect.js">

> Convenient and dependency free wrapper for working with arrays and objects