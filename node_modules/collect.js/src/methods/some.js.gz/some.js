'use strict';

const contains = require('./contains');

module.exports = contains;
