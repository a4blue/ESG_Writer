'use strict';

module.exports = function sortDesc() {
  return this.sort().reverse();
};
