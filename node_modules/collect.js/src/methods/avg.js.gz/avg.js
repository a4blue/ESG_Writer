'use strict';

const average = require('./average');

module.exports = average;
