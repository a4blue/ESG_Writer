'use strict';

module.exports = function dump() {
  // eslint-disable-next-line
  console.log(this);

  return this;
};
