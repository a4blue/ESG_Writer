'use strict';

module.exports = function all() {
  return this.items;
};
