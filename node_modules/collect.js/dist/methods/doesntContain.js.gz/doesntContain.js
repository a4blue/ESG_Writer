'use strict';

module.exports = function contains(key, value) {
  return !this.contains(key, value);
};