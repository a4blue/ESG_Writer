'use strict';

module.exports = function map(fn) {
  var _this = this;

  if (Array.isArray(this.items)) {
    return new this.constructor(this.items.map(fn));
  }

  var collection = {};
  Object.keys(this.items).forEach(function (key) {
    collection[key] = fn(_this.items[key], key);
  });
  return new this.constructor(collection);
};