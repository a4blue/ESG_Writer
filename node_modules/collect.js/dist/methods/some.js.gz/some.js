'use strict';

var contains = require('./contains');

module.exports = contains;