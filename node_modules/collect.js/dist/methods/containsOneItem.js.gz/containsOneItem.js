'use strict';

module.exports = function containsOneItem() {
  return this.count() === 1;
};