'use strict';

module.exports = function isNotEmpty() {
  return !this.isEmpty();
};