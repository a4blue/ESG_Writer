'use strict';

var average = require('./average');

module.exports = average;