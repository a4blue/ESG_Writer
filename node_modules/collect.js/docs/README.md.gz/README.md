---
home: true
actionText: Get Started →
actionLink: /installation/
features:
- title: 📄 Beautiful API
  details: Enjoy a beautiful API with names and conventions that makes sense.
- title: 🏗 Extendable
  details: Want to customize? Collect.js can be extended using macros.
- title: ❤️ Collect.js + Laravel
  details: A match made in heaven. Collect.js offers an identical api to Laravel collections.
footer: MIT Licensed | Copyright © Daniel Eckermann
---