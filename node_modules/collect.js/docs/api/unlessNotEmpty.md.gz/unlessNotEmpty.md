# `unlessNotEmpty()`

Alias for the [`whenEmpty()`](#whenEmpty) method

[View source on GitHub](https://github.com/ecrmnn/collect.js/blob/master/src/methods/unlessNotEmpty.js)