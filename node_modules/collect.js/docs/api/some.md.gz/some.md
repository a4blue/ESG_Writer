# `some()`

Alias for the [contains](#contains) method.

[View source on GitHub](https://github.com/ecrmnn/collect.js/blob/master/src/methods/some.js)