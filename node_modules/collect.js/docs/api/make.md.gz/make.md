# `make()`

The make method creates a new collection instance.

> This is only added to adhere to the Laravel collection API, when using Collect.js it's recommended to use `collect()` directly when creating a new collection.

[View source on GitHub](https://github.com/ecrmnn/collect.js/blob/master/src/methods/make.js)