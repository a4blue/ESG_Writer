# `sortKeysDesc()`
This method has the same signature as the [sortKeys](#sortkeys) method, but will sort the collection in the opposite order.

[View source on GitHub](https://github.com/ecrmnn/collect.js/blob/master/src/methods/sortKeysDesc.js)