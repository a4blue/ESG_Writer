# `unlessEmpty()`

Alias for the [`whenNotEmpty()`](#whenNotEmpty) method

[View source on GitHub](https://github.com/ecrmnn/collect.js/blob/master/src/methods/unlessEmpty.js)