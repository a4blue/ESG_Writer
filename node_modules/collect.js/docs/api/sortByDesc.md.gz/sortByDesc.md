# `sortByDesc()`

This method has the same signature as the `sortBy` method, but will sort the collection in the opposite order.

[View source on GitHub](https://github.com/ecrmnn/collect.js/blob/master/src/methods/sortByDesc.js)