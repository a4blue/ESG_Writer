# `average()`

Alias for the [`avg()`](#avg) method

[View source on GitHub](https://github.com/ecrmnn/collect.js/blob/master/src/methods/average.js)