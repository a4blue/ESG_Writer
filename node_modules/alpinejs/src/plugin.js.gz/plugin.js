import Alpine from './alpine'

export function plugin(callback) {
    callback(Alpine)
}
