import * as acorn from "./acorn";
export = acorn;