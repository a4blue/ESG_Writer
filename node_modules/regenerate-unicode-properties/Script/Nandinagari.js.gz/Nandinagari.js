const set = require('regenerate')();
set.addRange(0x119A0, 0x119A7).addRange(0x119AA, 0x119D7).addRange(0x119DA, 0x119E4);
exports.characters = set;
