declare function plugin(options?: { strategy?: 'base' | 'class' }): Function
export = plugin
