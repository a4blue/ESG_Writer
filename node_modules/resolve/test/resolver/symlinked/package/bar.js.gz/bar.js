module.exports = 'bar';
