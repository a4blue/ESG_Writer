declare type TSetImmediate = (callback: (...args: any[]) => void, args?: any) => void;
declare const _default: TSetImmediate;
export default _default;
