/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Florent Cailhol @ooflorent
*/

"use strict";

exports.STAGE_BASIC = -10;
exports.STAGE_DEFAULT = 0;
exports.STAGE_ADVANCED = 10;
