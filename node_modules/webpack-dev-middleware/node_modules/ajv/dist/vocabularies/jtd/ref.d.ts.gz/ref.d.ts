import type { CodeKeywordDefinition, AnySchemaObject } from "../../types";
declare const def: CodeKeywordDefinition;
export declare function hasRef(schema: AnySchemaObject): boolean;
export default def;
