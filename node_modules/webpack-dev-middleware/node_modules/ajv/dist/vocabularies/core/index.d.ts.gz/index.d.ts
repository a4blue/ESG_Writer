import type { Vocabulary } from "../../types";
declare const core: Vocabulary;
export default core;
