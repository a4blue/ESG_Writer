declare function quote(s: string): string;
declare namespace quote {
    var code: string;
}
export default quote;
