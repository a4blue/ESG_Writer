import type Ajv from "../../core";
export default function addMetaSchema2019(this: Ajv, $data?: boolean): Ajv;
