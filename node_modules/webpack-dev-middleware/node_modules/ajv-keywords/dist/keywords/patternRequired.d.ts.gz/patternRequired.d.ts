import type { Plugin } from "ajv";
declare const patternRequired: Plugin<undefined>;
export default patternRequired;
