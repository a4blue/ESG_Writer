import type { Plugin } from "ajv";
declare const deepRequired: Plugin<undefined>;
export default deepRequired;
