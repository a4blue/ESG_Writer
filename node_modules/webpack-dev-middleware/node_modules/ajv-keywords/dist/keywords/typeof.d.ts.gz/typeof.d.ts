import type { Plugin } from "ajv";
declare const typeofPlugin: Plugin<undefined>;
export default typeofPlugin;
