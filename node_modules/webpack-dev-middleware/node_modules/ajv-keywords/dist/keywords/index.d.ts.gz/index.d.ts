import type { Plugin } from "ajv";
declare const ajvKeywords: Record<string, Plugin<any> | undefined>;
export default ajvKeywords;
