import type { MacroKeywordDefinition } from "ajv";
import type { DefinitionOptions } from "./_types";
export default function getDef(opts?: DefinitionOptions): MacroKeywordDefinition;
