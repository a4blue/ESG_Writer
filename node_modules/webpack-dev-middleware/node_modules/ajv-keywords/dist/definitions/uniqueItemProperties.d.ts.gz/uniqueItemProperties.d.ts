import type { FuncKeywordDefinition } from "ajv";
export default function getDef(): FuncKeywordDefinition;
