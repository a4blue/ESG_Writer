"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = import_;

function import_(filepath) {
  return import(filepath);
}