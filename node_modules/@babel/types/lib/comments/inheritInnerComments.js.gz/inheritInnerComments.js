"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = inheritInnerComments;

var _inherit = require("../utils/inherit");

function inheritInnerComments(child, parent) {
  (0, _inherit.default)("innerComments", child, parent);
}