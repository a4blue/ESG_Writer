export default function _classPrivateMethodSet() {
  throw new TypeError("attempted to reassign private method");
}