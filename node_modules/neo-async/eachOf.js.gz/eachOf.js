'use strict';

module.exports = require('./async').eachOf;
