/**
 * IS `true` for Node.js 10.10 and greater.
 */
export declare const IS_SUPPORT_READDIR_WITH_FILE_TYPES: boolean;
