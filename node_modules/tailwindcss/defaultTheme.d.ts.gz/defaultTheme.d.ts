import type { Config } from './types/config'
declare const theme: Config['theme']
export = theme
