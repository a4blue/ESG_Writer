import type { Config } from './types/config'
declare const config: Config
export = config
