declare function _exports(selector: import('postcss-selector-parser').Selector, index: number, value: string): boolean | undefined | '';
export = _exports;
