module.exports = TextDecoder;
