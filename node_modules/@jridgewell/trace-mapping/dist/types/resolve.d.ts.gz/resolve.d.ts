export default function resolve(input: string, base: string | undefined): string;
