declare function _exports(value: string): [string, string, string];
export = _exports;
