declare const _exports: (prop: import('postcss').Declaration, includeCustomProps?: boolean | undefined) => boolean;
export = _exports;
