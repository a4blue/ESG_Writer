'use strict';
/** @type {(node: import('postcss').Declaration) => boolean} */
module.exports = (node) => node.value.search(/var\s*\(\s*--/i) !== -1;
