'use strict';
const base = require('./boxBase.js');

module.exports = base('margin');
