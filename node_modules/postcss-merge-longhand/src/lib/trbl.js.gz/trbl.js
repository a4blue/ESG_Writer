'use strict';
module.exports = ['top', 'right', 'bottom', 'left'];
