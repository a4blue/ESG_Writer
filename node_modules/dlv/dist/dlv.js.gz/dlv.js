module.exports=function(t,e,l,n,o){for(e=e.split?e.split("."):e,n=0;n<e.length;n++)t=t?t[e[n]]:o;return t===o?l:t};
//# sourceMappingURL=dlv.js.map
