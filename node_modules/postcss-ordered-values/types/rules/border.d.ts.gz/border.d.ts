declare function _exports(border: import('postcss-value-parser').ParsedValue): string;
export = _exports;
