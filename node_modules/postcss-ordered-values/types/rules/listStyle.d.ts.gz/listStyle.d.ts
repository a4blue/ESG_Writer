declare function _exports(listStyle: import('postcss-value-parser').ParsedValue): string;
export = _exports;
