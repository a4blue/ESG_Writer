'use strict';
// All of the curently implemented math functions
module.exports = new Set(['calc', 'clamp', 'max', 'min']);
