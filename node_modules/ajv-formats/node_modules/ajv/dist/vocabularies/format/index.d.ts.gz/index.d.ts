import type { Vocabulary } from "../../types";
declare const format: Vocabulary;
export default format;
