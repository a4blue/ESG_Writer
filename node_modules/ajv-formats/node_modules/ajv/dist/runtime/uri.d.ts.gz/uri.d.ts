import * as uri from "uri-js";
declare type URI = typeof uri & {
    code: string;
};
declare const _default: URI;
export default _default;
