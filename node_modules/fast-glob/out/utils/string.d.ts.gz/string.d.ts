export declare function isString(input: unknown): input is string;
export declare function isEmpty(input: string): boolean;
