/// <reference types="node" />
import { Readable } from 'stream';
export declare function merge(streams: Readable[]): NodeJS.ReadableStream;
