import { ErrnoException } from '../types';
export declare function isEnoentCodeError(error: ErrnoException): boolean;
