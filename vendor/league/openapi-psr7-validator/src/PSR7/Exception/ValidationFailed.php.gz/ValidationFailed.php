<?php

declare(strict_types=1);

namespace League\OpenAPIValidation\PSR7\Exception;

use Exception;

class ValidationFailed extends Exception
{
}
