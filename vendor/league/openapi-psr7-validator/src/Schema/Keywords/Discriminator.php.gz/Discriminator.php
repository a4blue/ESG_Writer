<?php

declare(strict_types=1);

namespace League\OpenAPIValidation\Schema\Keywords;

class Discriminator extends BaseKeyword
{
    /**
     * @param mixed $data
     */
    public function validate($data): void
    {
        // TODO
    }
}
