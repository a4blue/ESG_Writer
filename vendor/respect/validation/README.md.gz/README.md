# Respect\Validation

[![Build Status](https://img.shields.io/github/workflow/status/Respect/Validation/Continuous%20Integration/master?style=flat-square)](https://github.com/Respect/Validation/actions?query=workflow%3A%22Continuous+Integration%22)
[![Code Coverage](https://img.shields.io/codecov/c/github/Respect/Validation?style=flat-square)](https://codecov.io/gh/Respect/Validation)
[![Latest Stable Version](https://img.shields.io/packagist/v/respect/validation.svg?style=flat-square)](https://packagist.org/packages/respect/validation)
[![Total Downloads](https://img.shields.io/packagist/dt/respect/validation.svg?style=flat-square)](https://packagist.org/packages/respect/validation)
[![License](https://img.shields.io/packagist/l/respect/validation.svg?style=flat-square)](https://packagist.org/packages/respect/validation)

[The most awesome validation engine ever created for PHP.](http://bit.ly/1a1oeQv)

* [Documentation](https://respect-validation.readthedocs.io)
* [How to contribute](CONTRIBUTING.md)
