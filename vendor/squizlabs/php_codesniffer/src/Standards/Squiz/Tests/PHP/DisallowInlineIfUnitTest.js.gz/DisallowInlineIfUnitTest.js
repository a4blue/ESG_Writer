x = (x?a:x);
id = id.replace(/row\/:/gi, '');
