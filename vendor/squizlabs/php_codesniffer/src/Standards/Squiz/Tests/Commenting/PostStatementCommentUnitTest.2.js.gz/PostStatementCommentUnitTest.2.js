// Comment as first thing in a JS file.
var i = 100;
