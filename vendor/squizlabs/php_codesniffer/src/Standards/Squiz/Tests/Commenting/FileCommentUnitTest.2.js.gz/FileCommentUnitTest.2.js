/**
 * File comment.
 *
 * @package    Package
 * @subpackage Subpackage
 * @author     Squiz Pty Ltd <products@squiz.net>
 * @copyright  2010-2014 Squiz Pty Ltd (ABN 77 084 670 600)
 */

print 'hi';