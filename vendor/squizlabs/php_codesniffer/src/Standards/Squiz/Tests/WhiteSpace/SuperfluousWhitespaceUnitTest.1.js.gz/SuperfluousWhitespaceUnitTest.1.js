
alert('hi');
alert('hello');   
    
if (something) {  
    
}


function myFunction()
{
    alert('code here');

    alert('code here');


    // Hello.

    /*
        HI
    */


}

function myFunction2()
{
    alert('code here');


    alert('code here');

}

MyFunction = function()
{
    alert('code here');


    alert('code here');

};

// phpcs:set Squiz.WhiteSpace.SuperfluousWhitespace ignoreBlankLines true

function myFunction2()
{
    alert('code here');
    
    alert('code here');
    
}

// phpcs:set Squiz.WhiteSpace.SuperfluousWhitespace ignoreBlankLines false


