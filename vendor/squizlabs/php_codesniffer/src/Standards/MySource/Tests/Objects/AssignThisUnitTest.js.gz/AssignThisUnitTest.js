var self = this;
buttonWidget.addClickEvent(function() {
    self.addDynamicSouce();
});

var x = self;
var y = this;

var test = '';
if (true) {
    test = this
}

var itemid = this.items[i].getAttribute('itemid');

for (var x = this; y < 10; y++) {
    var x = this + 1;
}

var _self = this;