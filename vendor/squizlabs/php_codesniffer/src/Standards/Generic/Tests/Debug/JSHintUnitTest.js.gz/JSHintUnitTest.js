/* jshint undef: true, unused: true */

var foo = bar;
