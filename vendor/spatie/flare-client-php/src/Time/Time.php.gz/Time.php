<?php

namespace Spatie\FlareClient\Time;

interface Time
{
    public function getCurrentTime(): int;
}
