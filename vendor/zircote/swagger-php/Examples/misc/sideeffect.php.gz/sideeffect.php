<?php

// this should not get loaded...

die(1);
