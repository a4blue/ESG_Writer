<?php

namespace OpenApi\Examples\UsingLinks;

use OpenApi\Annotations as OA;

/**
 * @OA\Info(
 *     title="Link Example",
 *     version="1.0.0"
 * )
 */
class OpenApiSpec
{
}
