<?php

namespace OpenApi\Examples\UsingLinksPhp81;

use OpenApi\Attributes as OAT;

#[OAT\Info(version: '1.0.0', title: 'Link Example')]
class OpenApiSpec
{
}
