<?php

namespace Illuminate\Foundation\Events;

class MaintenanceModeDisabled
{
    //
}
