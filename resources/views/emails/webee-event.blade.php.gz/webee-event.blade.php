<div>{{$webeeEvent->title}}</div>
<br/>
<div>{{$webeeEvent->event_url}}</div>
<br/>
<div style="max-width:50%;">{{$webeeEvent->description_long}}</div>
