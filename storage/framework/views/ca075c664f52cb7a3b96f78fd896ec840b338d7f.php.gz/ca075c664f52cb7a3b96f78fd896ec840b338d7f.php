<div><?php echo e($webeeEvent->title); ?></div>
<br/>
<div><?php echo e($webeeEvent->event_url); ?></div>
<br/>
<div style="max-width:50%;"><?php echo e($webeeEvent->description_long); ?></div>
<?php /**PATH /home/a4blue/Development/ESG-Writer/resources/views/emails/webee-event.blade.php ENDPATH**/ ?>